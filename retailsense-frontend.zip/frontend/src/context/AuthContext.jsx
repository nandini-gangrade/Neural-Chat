import { createContext, useContext, useEffect, useState } from 'react';
import Papa from 'papaparse';
import authUsersCsv from '../data/auth_users.csv?raw';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('auth_user');
    return stored ? JSON.parse(stored) : null;
  });

  const parseUsers = () => {
    const result = Papa.parse(authUsersCsv, { header: true, skipEmptyLines: true });
    return result.data;
  };

  const login = (email, password, role, secretKey) => {
    const users = parseUsers();
    const found = users.find(
      (u) =>
        u.email === email &&
        u.password === password &&
        u.role === role &&
        (role !== 'admin' || u.secret_key === secretKey)
    );
    if (found) {
      const userData = { user_id: found.user_id, name: found.name, email: found.email, role: found.role };
      setUser(userData);
      localStorage.setItem('auth_user', JSON.stringify(userData));
      return { success: true, user: userData };
    }
    return { success: false, message: 'Invalid credentials. Please check your email, password, and role.' };
  };

  const register = (name, email, password) => {
    const users = parseUsers();
    if (users.find((u) => u.email === email)) {
      return { success: false, message: 'Email already registered.' };
    }
    const newUser = { user_id: 'U_' + Date.now(), name, email, role: 'user' };
    setUser(newUser);
    localStorage.setItem('auth_user', JSON.stringify(newUser));
    return { success: true, user: newUser };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('auth_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

import { useTheme } from '../context/ThemeContext';

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="relative inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-300
        bg-slate-700 hover:bg-slate-600 text-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600"
      title="Toggle theme"
    >
      <span className="text-base">{theme === 'dark' ? '☀️' : '🌙'}</span>
      <span className="hidden sm:inline">{theme === 'dark' ? 'Light' : 'Dark'}</span>
    </button>
  );
};

export default ThemeToggle;

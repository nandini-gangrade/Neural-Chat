import { useState, useRef, useEffect } from 'react';
import { sendChatMessage } from '../api/chatbot';

const Chatbot = ({ mode = 'user' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      text: mode === 'admin'
        ? '👋 Hi Admin! Ask me anything about review trends, sentiment analysis, or product performance.'
        : '👋 Hi! Ask me about product recommendations, reviews, or sentiment summaries.',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: 'user', text: input, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const res = await sendChatMessage(input, mode);
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: res.data.reply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', text: 'Sorry, something went wrong. Please try again.', time: '' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Toggle button */}
      <button
        onClick={() => setIsOpen((o) => !o)}
        className={`w-14 h-14 rounded-full shadow-2xl flex items-center justify-center text-2xl transition-all duration-300
          ${mode === 'admin' ? 'bg-amber-500 hover:bg-amber-400' : 'bg-indigo-600 hover:bg-indigo-500'}`}
      >
        {isOpen ? '✕' : '💬'}
      </button>

      {/* Chat window */}
      {isOpen && (
        <div className="absolute bottom-16 right-0 w-80 sm:w-96 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          style={{ height: '420px' }}>
          {/* Header */}
          <div className={`px-4 py-3 flex items-center gap-2 ${mode === 'admin' ? 'bg-amber-500/10 border-b border-amber-500/20' : 'bg-indigo-500/10 border-b border-indigo-500/20'}`}>
            <span className="text-xl">{mode === 'admin' ? '🔐' : '🤖'}</span>
            <div>
              <p className="text-white text-sm font-semibold">{mode === 'admin' ? 'Admin Intelligence Bot' : 'Review Assistant'}</p>
              <p className="text-slate-400 text-xs">AI-powered • Demo mode</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] px-3 py-2 rounded-xl text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-br-none'
                    : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none'
                }`}>
                  {msg.text}
                  {msg.time && <p className="text-xs opacity-50 mt-1 text-right">{msg.time}</p>}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-slate-400 text-sm">
                  <span className="animate-pulse">Thinking...</span>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-slate-700 flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 bg-slate-800 text-white text-sm px-3 py-2 rounded-xl border border-slate-600 focus:outline-none focus:border-indigo-500 placeholder-slate-500"
            />
            <button
              onClick={sendMessage}
              disabled={loading}
              className={`px-3 py-2 rounded-xl text-sm font-medium transition ${
                mode === 'admin' ? 'bg-amber-500 hover:bg-amber-400' : 'bg-indigo-600 hover:bg-indigo-500'
              } text-white disabled:opacity-50`}
            >
              ➤
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;

import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ThemeToggle from './ThemeToggle';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur border-b border-slate-700/60 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        {/* Logo */}
        <Link to={user?.role === 'admin' ? '/admin/dashboard' : '/user/dashboard'} className="flex items-center gap-2">
          <span className="text-2xl">🛍️</span>
          <span className="font-bold text-white text-lg tracking-tight hidden sm:block">
            Retail<span className="text-indigo-400">Sense</span>
          </span>
        </Link>

        {/* Nav links */}
        {user && (
          <div className="flex items-center gap-1 sm:gap-2">
            {user.role === 'admin' ? (
              <Link
                to="/admin/dashboard"
                className="px-3 py-1.5 rounded-lg text-sm text-slate-300 hover:text-white hover:bg-slate-700 transition"
              >
                Dashboard
              </Link>
            ) : (
              <Link
                to="/user/dashboard"
                className="px-3 py-1.5 rounded-lg text-sm text-slate-300 hover:text-white hover:bg-slate-700 transition"
              >
                Dashboard
              </Link>
            )}
          </div>
        )}

        {/* Right controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          <ThemeToggle />
          {user ? (
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-full border border-slate-700">
                <div className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-xs font-bold text-white">
                  {user.name?.[0]?.toUpperCase() || 'U'}
                </div>
                <span className="text-slate-300 text-sm">{user.name}</span>
                <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${user.role === 'admin' ? 'bg-amber-500/20 text-amber-400' : 'bg-indigo-500/20 text-indigo-400'}`}>
                  {user.role}
                </span>
              </div>
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-lg text-sm bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 transition"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="px-4 py-1.5 rounded-lg text-sm bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

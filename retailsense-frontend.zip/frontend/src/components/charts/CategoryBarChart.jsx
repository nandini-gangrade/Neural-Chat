import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const CategoryBarChart = ({ data }) => {
  const chartData = data || [
    { category: 'Electronics', avgRating: 4.3 },
    { category: 'Footwear', avgRating: 4.3 },
    { category: 'Food & Bev', avgRating: 3.5 },
    { category: 'Furniture', avgRating: 2.5 },
    { category: 'Sports', avgRating: 5.0 },
    { category: 'Beauty', avgRating: 4.5 },
    { category: 'Bags', avgRating: 5.0 },
  ];

  const getColor = (rating) => {
    if (rating >= 4.5) return '#22c55e';
    if (rating >= 3.5) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
        <XAxis dataKey="category" tick={{ fill: '#94a3b8', fontSize: 11 }} />
        <YAxis domain={[0, 5]} tick={{ fill: '#94a3b8', fontSize: 11 }} />
        <Tooltip
          contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, color: '#f1f5f9' }}
          formatter={(value) => [value.toFixed(1), 'Avg Rating']}
        />
        <Bar dataKey="avgRating" radius={[4, 4, 0, 0]}>
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={getColor(entry.avgRating)} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default CategoryBarChart;

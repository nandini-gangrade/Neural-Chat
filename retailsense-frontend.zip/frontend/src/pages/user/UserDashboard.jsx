import { useEffect, useState } from 'react';
import { getProducts, getSentimentOverview, getProductReviews, getUserDashboard } from '../../api/user';
import SentimentPieChart from '../../components/charts/SentimentPieChart';
import Chatbot from '../../components/Chatbot';
import { useAuth } from '../../context/AuthContext';

const CATEGORIES = ['All', 'Electronics', 'Footwear', 'Food & Beverage', 'Furniture', 'Sports', 'Beauty', 'Bags', 'Kitchen', 'Accessories'];

const sentimentBadge = (s) => {
  if (s === 'positive') return 'bg-green-500/15 text-green-400';
  if (s === 'negative') return 'bg-red-500/15 text-red-400';
  return 'bg-yellow-500/15 text-yellow-400';
};

const UserDashboard = () => {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [sentiment, setSentiment] = useState(null);
  const [dashStats, setDashStats] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [productReviews, setProductReviews] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getProducts(), getSentimentOverview(), getUserDashboard(user?.user_id)]).then(
      ([p, s, d]) => {
        setProducts(p.data);
        setSentiment(s.data);
        setDashStats(d.data);
        setLoading(false);
      }
    );
  }, []);

  const handleProductClick = async (product) => {
    setSelectedProduct(product);
    const res = await getProductReviews(product.id);
    setProductReviews(res.data);
  };

  const filtered =
    selectedCategory === 'All' ? products : products.filter((p) => p.category === selectedCategory);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl animate-bounce mb-4">🛍️</div>
          <p className="text-slate-400">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-1">
            Welcome back, <span className="text-indigo-400">{user?.name?.split(' ')[0]}</span> 👋
          </h1>
          <p className="text-slate-400 text-sm">Explore products, read reviews, and discover sentiment insights.</p>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-indigo-400">{dashStats?.recentReviews || 3}</p>
            <p className="text-slate-400 text-xs mt-1">Your Reviews</p>
          </div>
          <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-amber-400">{dashStats?.avgRating || 4.2}</p>
            <p className="text-slate-400 text-xs mt-1">Avg Rating Given</p>
          </div>
          <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-green-400">{dashStats?.favoriteCategory || 'Electronics'}</p>
            <p className="text-slate-400 text-xs mt-1">Top Category</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left: Products */}
          <div className="lg:col-span-2">
            {/* Category filter */}
            <div className="flex gap-2 flex-wrap mb-4">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Product grid */}
            <div className="grid sm:grid-cols-2 gap-4">
              {filtered.map((p) => (
                <div
                  key={p.id}
                  onClick={() => handleProductClick(p)}
                  className={`bg-slate-900 border rounded-2xl p-4 cursor-pointer transition hover:scale-[1.02] hover:shadow-lg ${
                    selectedProduct?.id === p.id ? 'border-indigo-500 shadow-indigo-500/20 shadow-lg' : 'border-slate-700/60 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xs bg-indigo-500/15 text-indigo-400 px-2 py-0.5 rounded-full">{p.category}</span>
                    <span className="text-green-400 font-bold text-sm">${p.price}</span>
                  </div>
                  <h4 className="text-white font-medium text-sm leading-snug mb-2">{p.name}</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 text-xs">★ {p.rating}</span>
                    <span className="text-slate-500 text-xs">({p.reviewCount} reviews)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Sentiment + Product detail */}
          <div className="space-y-5">
            {/* Sentiment overview */}
            <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-5">
              <h3 className="text-white font-semibold mb-1 text-sm">Overall Sentiment</h3>
              <p className="text-slate-500 text-xs mb-3">Across all {sentiment?.total} reviews</p>
              <SentimentPieChart
                data={[
                  { name: 'Positive', value: sentiment?.positive || 14 },
                  { name: 'Neutral', value: sentiment?.neutral || 3 },
                  { name: 'Negative', value: sentiment?.negative || 3 },
                ]}
              />
              <div className="mt-3 flex justify-around text-center text-xs">
                <div>
                  <p className="text-green-400 font-bold">{Math.round(((sentiment?.positive || 14) / (sentiment?.total || 20)) * 100)}%</p>
                  <p className="text-slate-500">Positive</p>
                </div>
                <div>
                  <p className="text-yellow-400 font-bold">{Math.round(((sentiment?.neutral || 3) / (sentiment?.total || 20)) * 100)}%</p>
                  <p className="text-slate-500">Neutral</p>
                </div>
                <div>
                  <p className="text-red-400 font-bold">{Math.round(((sentiment?.negative || 3) / (sentiment?.total || 20)) * 100)}%</p>
                  <p className="text-slate-500">Negative</p>
                </div>
              </div>
            </div>

            {/* Product reviews panel */}
            {selectedProduct && productReviews && (
              <div className="bg-slate-900 border border-indigo-500/30 rounded-2xl p-5">
                <h3 className="text-white font-semibold text-sm mb-1">{selectedProduct.name}</h3>
                <p className="text-slate-400 text-xs mb-3">Review Summary & Insights</p>
                <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-3 mb-4">
                  <p className="text-slate-300 text-xs leading-relaxed">{productReviews.summary}</p>
                </div>
                <div className="space-y-2">
                  {productReviews.reviews.map((r) => (
                    <div key={r.id} className="border border-slate-700/50 rounded-xl p-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-slate-300 text-xs font-medium">{r.user}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${sentimentBadge(r.sentiment)}`}>{r.sentiment}</span>
                      </div>
                      <p className="text-slate-400 text-xs">{r.body}</p>
                      <div className="mt-1 flex items-center gap-1">
                        <span className="text-amber-400 text-xs">{'★'.repeat(r.rating)}</span>
                        <span className="text-slate-600 text-xs">{r.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Chatbot mode="user" />
    </div>
  );
};

export default UserDashboard;

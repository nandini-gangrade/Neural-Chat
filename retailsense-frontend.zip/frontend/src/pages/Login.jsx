import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState('user');
  const [form, setForm] = useState({ email: '', password: '', secretKey: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    await new Promise((r) => setTimeout(r, 300)); // simulate delay
    const result = login(form.email, form.password, role, form.secretKey);
    setLoading(false);
    if (result.success) {
      navigate(role === 'admin' ? '/admin/dashboard' : '/user/dashboard');
    } else {
      setError(result.message);
    }
  };

  const fillDemo = (demoRole) => {
    if (demoRole === 'admin') setForm({ email: 'admin1@store.com', password: 'admin123', secretKey: 'ADMIN-KEY-001' });
    else setForm({ email: 'john@example.com', password: 'user123', secretKey: '' });
    setRole(demoRole);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-indigo-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🛍️</div>
          <h1 className="text-3xl font-bold text-white">RetailSense</h1>
          <p className="text-slate-400 mt-1">Review Sentiment & Analytics Platform</p>
        </div>

        {/* Role toggle */}
        <div className="flex bg-slate-800/60 rounded-xl p-1 mb-6 border border-slate-700">
          {['user', 'admin'].map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                role === r ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {r === 'admin' ? '🔐 Admin' : '👤 User'}
            </button>
          ))}
        </div>

        {/* Card */}
        <div className="bg-slate-900/80 backdrop-blur border border-slate-700/60 rounded-2xl p-6 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-slate-300 text-sm font-medium block mb-1.5">Email</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                required
                placeholder="you@example.com"
                className="w-full bg-slate-800 text-white px-4 py-2.5 rounded-xl border border-slate-600 focus:outline-none focus:border-indigo-500 placeholder-slate-500 text-sm"
              />
            </div>
            <div>
              <label className="text-slate-300 text-sm font-medium block mb-1.5">Password</label>
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                required
                placeholder="••••••••"
                className="w-full bg-slate-800 text-white px-4 py-2.5 rounded-xl border border-slate-600 focus:outline-none focus:border-indigo-500 placeholder-slate-500 text-sm"
              />
            </div>
            {role === 'admin' && (
              <div>
                <label className="text-slate-300 text-sm font-medium block mb-1.5">Secret Key</label>
                <input
                  type="text"
                  name="secretKey"
                  value={form.secretKey}
                  onChange={handleChange}
                  required
                  placeholder="ADMIN-KEY-XXX"
                  className="w-full bg-slate-800 text-white px-4 py-2.5 rounded-xl border border-amber-600/50 focus:outline-none focus:border-amber-500 placeholder-slate-500 text-sm"
                />
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-sm px-4 py-2.5 rounded-xl">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-all disabled:opacity-60 disabled:cursor-not-allowed mt-2"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-4 pt-4 border-t border-slate-700/60">
            <p className="text-slate-500 text-xs text-center mb-2">Quick demo access</p>
            <div className="flex gap-2">
              <button onClick={() => fillDemo('user')} className="flex-1 py-1.5 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition">
                👤 Fill User
              </button>
              <button onClick={() => fillDemo('admin')} className="flex-1 py-1.5 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition">
                🔐 Fill Admin
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-slate-500 text-sm mt-4">
          Don't have an account?{' '}
          <Link to="/register" className="text-indigo-400 hover:text-indigo-300">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Login;

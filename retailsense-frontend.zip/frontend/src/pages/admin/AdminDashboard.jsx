import { useEffect, useState } from 'react';
import { getAdminStats, getAllReviews, getCategoryStats, getAllProducts } from '../../api/admin';
import SentimentPieChart from '../../components/charts/SentimentPieChart';
import CategoryBarChart from '../../components/charts/CategoryBarChart';
import Chatbot from '../../components/Chatbot';
import { useAuth } from '../../context/AuthContext';

const StatCard = ({ icon, label, value, sub, color }) => (
  <div className={`bg-slate-900 border border-slate-700/60 rounded-2xl p-5 flex items-start gap-4 hover:border-slate-600 transition`}>
    <div className={`text-3xl p-2 rounded-xl ${color}`}>{icon}</div>
    <div>
      <p className="text-slate-400 text-sm">{label}</p>
      <p className="text-white text-2xl font-bold">{value}</p>
      {sub && <p className="text-slate-500 text-xs mt-0.5">{sub}</p>}
    </div>
  </div>
);

const sentimentBadge = (s) => {
  if (s === 'positive') return 'bg-green-500/15 text-green-400 border border-green-500/20';
  if (s === 'negative') return 'bg-red-500/15 text-red-400 border border-red-500/20';
  return 'bg-yellow-500/15 text-yellow-400 border border-yellow-500/20';
};

const AdminDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [catStats, setCatStats] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    Promise.all([getAdminStats(), getAllReviews(), getCategoryStats(), getAllProducts()]).then(
      ([s, r, c, p]) => {
        setStats(s.data);
        setReviews(r.data);
        setCatStats(c.data);
        setProducts(p.data);
        setLoading(false);
      }
    );
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl animate-bounce mb-4">📊</div>
          <p className="text-slate-400">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <span className="text-2xl">🔐</span>
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <span className="px-2.5 py-1 bg-amber-500/15 text-amber-400 text-xs font-medium rounded-full border border-amber-500/20">
              Admin Panel
            </span>
          </div>
          <p className="text-slate-400 text-sm">Welcome back, <span className="text-white">{user?.name}</span> · Retail Sentiment Intelligence</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard icon="📝" label="Total Reviews" value={stats.totalReviews} sub="All time" color="bg-indigo-500/10" />
          <StatCard icon="📦" label="Products" value={stats.totalProducts} sub="In catalog" color="bg-purple-500/10" />
          <StatCard icon="👥" label="Users" value={stats.totalUsers} sub="Registered" color="bg-blue-500/10" />
          <StatCard icon="⭐" label="Avg Rating" value={stats.avgRating} sub="Across all products" color="bg-amber-500/10" />
        </div>

        {/* Sentiment quick stats */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-green-400">{stats.positiveCount}</p>
            <p className="text-green-300/70 text-xs mt-1">Positive Reviews</p>
          </div>
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-yellow-400">{stats.neutralCount}</p>
            <p className="text-yellow-300/70 text-xs mt-1">Neutral Reviews</p>
          </div>
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-red-400">{stats.negativeCount}</p>
            <p className="text-red-300/70 text-xs mt-1">Negative Reviews</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-slate-800/50 rounded-xl p-1 mb-6 w-fit">
          {['overview', 'reviews', 'products'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition ${
                activeTab === tab ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab === 'overview' ? '📊 Overview' : tab === 'reviews' ? '💬 Reviews' : '📦 Products'}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-5">
              <h3 className="text-white font-semibold mb-4">Sentiment Distribution</h3>
              <SentimentPieChart
                data={[
                  { name: 'Positive', value: stats.positiveCount },
                  { name: 'Neutral', value: stats.neutralCount },
                  { name: 'Negative', value: stats.negativeCount },
                ]}
              />
            </div>
            <div className="bg-slate-900 border border-slate-700/60 rounded-2xl p-5">
              <h3 className="text-white font-semibold mb-4">Avg Rating by Category</h3>
              <CategoryBarChart data={catStats} />
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="bg-slate-900 border border-slate-700/60 rounded-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-700/60">
              <h3 className="text-white font-semibold">All Reviews</h3>
              <p className="text-slate-400 text-sm">{reviews.length} reviews loaded</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700/60 text-slate-400 text-left">
                    <th className="px-5 py-3 font-medium">ID</th>
                    <th className="px-5 py-3 font-medium">Product</th>
                    <th className="px-5 py-3 font-medium">User</th>
                    <th className="px-5 py-3 font-medium">Rating</th>
                    <th className="px-5 py-3 font-medium">Sentiment</th>
                    <th className="px-5 py-3 font-medium">Date</th>
                    <th className="px-5 py-3 font-medium">Review</th>
                  </tr>
                </thead>
                <tbody>
                  {reviews.map((r, i) => (
                    <tr key={r.id} className={`border-b border-slate-800 hover:bg-slate-800/40 transition ${i % 2 === 0 ? '' : 'bg-slate-800/20'}`}>
                      <td className="px-5 py-3 text-slate-400 font-mono text-xs">{r.id}</td>
                      <td className="px-5 py-3 text-white font-medium">{r.product}</td>
                      <td className="px-5 py-3 text-slate-300">{r.user}</td>
                      <td className="px-5 py-3">
                        <span className="text-amber-400">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${sentimentBadge(r.sentiment)}`}>
                          {r.sentiment}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-slate-400 text-xs">{r.date}</td>
                      <td className="px-5 py-3 text-slate-300 max-w-xs truncate">{r.body}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.map((p) => (
              <div key={p.id} className="bg-slate-900 border border-slate-700/60 rounded-2xl p-5 hover:border-slate-500 transition">
                <div className="flex items-start justify-between mb-3">
                  <span className="text-xs text-slate-500 font-mono">{p.id}</span>
                  <span className="text-xs bg-indigo-500/15 text-indigo-400 px-2 py-0.5 rounded-full border border-indigo-500/20">{p.category}</span>
                </div>
                <h4 className="text-white font-semibold text-sm mb-2 leading-snug">{p.name}</h4>
                <div className="flex items-center justify-between mt-3">
                  <div>
                    <p className="text-amber-400 text-sm font-bold">★ {p.rating}</p>
                    <p className="text-slate-500 text-xs">{p.reviewCount} reviews</p>
                  </div>
                  <p className="text-green-400 font-bold">${p.price}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Chatbot mode="admin" />
    </div>
  );
};

export default AdminDashboard;

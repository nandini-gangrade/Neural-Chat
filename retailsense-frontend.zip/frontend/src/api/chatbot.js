// Dummy Chatbot API – replace with real backend calls when ready
import axiosClient from './axiosClient';

const adminResponses = [
  "Based on the sentiment analysis, 70% of reviews this week are positive. Electronics leads with highest satisfaction.",
  "The Ergonomic Office Chair has 2 negative reviews flagged for quality issues. Recommend follow-up with supplier.",
  "Running Shoes Pro X has the highest review volume this month with strong positive sentiment.",
  "Average rating across all products is 4.1/5. Beauty and Sports categories are performing best.",
  "I've detected a spike in negative reviews for the Wireless Headphones regarding connectivity. Suggest a product alert.",
];

const userResponses = [
  "Based on reviews, the Wireless Headphones are highly rated for sound quality and noise cancellation!",
  "The Yoga Mat Premium has the best user satisfaction score in the Sports category — customers love the grip!",
  "Looking for electronics? The Smart Watch Series 5 has 4.4 stars and excellent fitness tracking reviews.",
  "The Organic Green Tea Set is a top pick in Food & Beverage with a 4.7 rating.",
  "I can help you find the best-reviewed product in any category! Just ask me.",
];

export const sendChatMessage = async (message, mode = 'user') => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const pool = mode === 'admin' ? adminResponses : userResponses;
      const reply = pool[Math.floor(Math.random() * pool.length)];
      resolve({
        data: {
          reply,
          timestamp: new Date().toISOString(),
        },
      });
    }, 600);
  });
};

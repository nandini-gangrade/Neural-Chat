// Dummy Admin API – replace with real backend calls when ready
import axiosClient from './axiosClient';

export const getAdminStats = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          totalReviews: 20,
          totalProducts: 10,
          totalUsers: 5,
          avgRating: 4.1,
          positiveCount: 14,
          negativeCount: 3,
          neutralCount: 3,
        },
      });
    }, 300);
  });
};

export const getAllReviews = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: [
          { id: 'R001', product: 'Wireless Headphones', user: 'John Doe', rating: 5, sentiment: 'positive', date: '2024-01-15', body: 'These headphones are absolutely incredible.' },
          { id: 'R002', product: 'Wireless Headphones', user: 'Meera Patel', rating: 4, sentiment: 'positive', date: '2024-01-18', body: 'Sound quality is excellent.' },
          { id: 'R003', product: 'Wireless Headphones', user: 'Xiao Long', rating: 2, sentiment: 'negative', date: '2024-01-20', body: 'Keeps disconnecting from my phone.' },
          { id: 'R004', product: 'Running Shoes Pro X', user: 'John Doe', rating: 5, sentiment: 'positive', date: '2024-01-22', body: 'Best running shoes ever!' },
          { id: 'R005', product: 'Running Shoes Pro X', user: 'Arjun Singh', rating: 3, sentiment: 'neutral', date: '2024-01-25', body: 'Decent shoes but nothing special.' },
          { id: 'R006', product: 'Organic Green Tea Set', user: 'Meera Patel', rating: 5, sentiment: 'positive', date: '2024-01-28', body: 'The green tea is absolutely delicious.' },
          { id: 'R007', product: 'Ergonomic Office Chair', user: 'Sarah Kim', rating: 4, sentiment: 'positive', date: '2024-02-01', body: 'My back pain has reduced.' },
          { id: 'R008', product: 'Ergonomic Office Chair', user: 'Xiao Long', rating: 1, sentiment: 'negative', date: '2024-02-03', body: 'The chair arrived with a broken armrest.' },
        ],
      });
    }, 300);
  });
};

export const getCategoryStats = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: [
          { category: 'Electronics', avgRating: 4.3, reviewCount: 7 },
          { category: 'Footwear', avgRating: 4.3, reviewCount: 3 },
          { category: 'Food & Bev', avgRating: 3.5, reviewCount: 2 },
          { category: 'Furniture', avgRating: 2.5, reviewCount: 2 },
          { category: 'Sports', avgRating: 5.0, reviewCount: 1 },
          { category: 'Beauty', avgRating: 4.5, reviewCount: 2 },
          { category: 'Bags', avgRating: 5.0, reviewCount: 1 },
        ],
      });
    }, 300);
  });
};

export const getAllProducts = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: [
          { id: 'P001', name: 'Wireless Noise-Cancelling Headphones', category: 'Electronics', price: 149.99, rating: 4.5, reviewCount: 320 },
          { id: 'P002', name: 'Running Shoes Pro X', category: 'Footwear', price: 89.99, rating: 4.3, reviewCount: 210 },
          { id: 'P003', name: 'Organic Green Tea Set', category: 'Food & Beverage', price: 24.99, rating: 4.7, reviewCount: 150 },
          { id: 'P004', name: 'Ergonomic Office Chair', category: 'Furniture', price: 299.99, rating: 4.2, reviewCount: 180 },
          { id: 'P005', name: 'Yoga Mat Premium', category: 'Sports', price: 45.99, rating: 4.6, reviewCount: 95 },
          { id: 'P006', name: 'Smart Watch Series 5', category: 'Electronics', price: 199.99, rating: 4.4, reviewCount: 410 },
          { id: 'P007', name: 'Leather Wallet Slim', category: 'Accessories', price: 39.99, rating: 4.1, reviewCount: 130 },
          { id: 'P008', name: 'Blender Pro 1000W', category: 'Kitchen', price: 79.99, rating: 4.5, reviewCount: 220 },
          { id: 'P009', name: 'Sunscreen SPF 50', category: 'Beauty', price: 18.99, rating: 4.3, reviewCount: 310 },
          { id: 'P010', name: 'Backpack Urban 30L', category: 'Bags', price: 65.99, rating: 4.4, reviewCount: 175 },
        ],
      });
    }, 300);
  });
};

// Dummy User API – replace with real backend calls when ready
import axiosClient from './axiosClient';

export const getUserDashboard = async (userId) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          recentReviews: 3,
          favoriteCategory: 'Electronics',
          avgRating: 4.2,
        },
      });
    }, 300);
  });
};

export const getProducts = async (category = null) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: [
          { id: 'P001', name: 'Wireless Noise-Cancelling Headphones', category: 'Electronics', price: 149.99, rating: 4.5, reviewCount: 320 },
          { id: 'P002', name: 'Running Shoes Pro X', category: 'Footwear', price: 89.99, rating: 4.3, reviewCount: 210 },
          { id: 'P003', name: 'Organic Green Tea Set', category: 'Food & Beverage', price: 24.99, rating: 4.7, reviewCount: 150 },
          { id: 'P004', name: 'Ergonomic Office Chair', category: 'Furniture', price: 299.99, rating: 4.2, reviewCount: 180 },
          { id: 'P005', name: 'Yoga Mat Premium', category: 'Sports', price: 45.99, rating: 4.6, reviewCount: 95 },
          { id: 'P006', name: 'Smart Watch Series 5', category: 'Electronics', price: 199.99, rating: 4.4, reviewCount: 410 },
          { id: 'P007', name: 'Leather Wallet Slim', category: 'Accessories', price: 39.99, rating: 4.1, reviewCount: 130 },
          { id: 'P008', name: 'Blender Pro 1000W', category: 'Kitchen', price: 79.99, rating: 4.5, reviewCount: 220 },
          { id: 'P009', name: 'Sunscreen SPF 50', category: 'Beauty', price: 18.99, rating: 4.3, reviewCount: 310 },
          { id: 'P010', name: 'Backpack Urban 30L', category: 'Bags', price: 65.99, rating: 4.4, reviewCount: 175 },
        ],
      });
    }, 300);
  });
};

export const getProductReviews = async (productId) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          summary: 'Customers generally love this product for its quality and performance. A few noted minor issues with durability.',
          sentimentBreakdown: { positive: 70, neutral: 20, negative: 10 },
          reviews: [
            { id: 'R001', user: 'John Doe', rating: 5, sentiment: 'positive', date: '2024-01-15', body: 'Absolutely incredible product!' },
            { id: 'R002', user: 'Meera Patel', rating: 4, sentiment: 'positive', date: '2024-01-18', body: 'Great quality, worth the price.' },
          ],
        },
      });
    }, 300);
  });
};

export const getSentimentOverview = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          positive: 14,
          neutral: 3,
          negative: 3,
          total: 20,
        },
      });
    }, 300);
  });
};

// Dummy auth API – replace with real backend calls when ready
import axiosClient from './axiosClient';

export const loginUser = async (email, password, role, secretKey) => {
  // DUMMY RESPONSE – backend team replaces this
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          token: 'dummy_token_' + Date.now(),
          user: { email, role, name: email.split('@')[0] },
        },
      });
    }, 400);
  });
};

export const registerUser = async (userData) => {
  // DUMMY RESPONSE
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          message: 'Registration successful (demo mode)',
          user: { ...userData, user_id: 'U_' + Date.now() },
        },
      });
    }, 400);
  });
};

export const logoutUser = async () => {
  // DUMMY RESPONSE
  return new Promise((resolve) => setTimeout(() => resolve({ data: { message: 'Logged out' } }), 200));
};

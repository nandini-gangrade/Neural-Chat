# 🛍️ RetailSense — Review Sentiment & Summary Agent (Frontend)

A React.js (Vite + Tailwind) frontend for a retail product review sentiment analysis platform.

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open browser at http://localhost:5173
```

## 🔐 Demo Credentials

| Role  | Email                  | Password  | Secret Key     |
|-------|------------------------|-----------|----------------|
| Admin | admin1@store.com       | admin123  | ADMIN-KEY-001  |
| Admin | admin2@store.com       | admin123  | ADMIN-KEY-002  |
| User  | john@example.com       | user123   | —              |
| User  | meera@example.com      | user123   | —              |
| User  | xiao@example.com       | user123   | —              |

> Use the **Quick Fill** buttons on the Login page for instant access.

## 📁 Project Structure

```
frontend/
 ├── src/
 │    ├── data/          # CSV files (auth_users, products, reviews)
 │    ├── api/           # Axios dummy API functions
 │    ├── components/    # Navbar, ThemeToggle, Chatbot, Charts
 │    ├── context/       # AuthContext, ThemeContext
 │    └── pages/         # Login, Register, AdminDashboard, UserDashboard
 ├── index.html
 ├── package.json
 ├── vite.config.js
 └── tailwind.config.js
```

## 🛠️ Tech Stack

- **React 18** + **Vite 5**
- **TailwindCSS 3**
- **React Router v6**
- **Recharts** (Pie + Bar charts)
- **Axios** (with dummy responses — backend-ready)
- **PapaParse** (CSV parsing for demo auth)
- **Context API** (Auth + Theme)

## 🔌 Connecting to Backend

All API calls live in `src/api/`. Each file has dummy responses.  
To connect your backend:

1. Set `VITE_API_BASE_URL` in `.env`
2. Replace dummy `Promise` responses with real `axiosClient.get(...)` / `post(...)` calls

Example replacement in `src/api/admin.js`:
```js
// Before (dummy)
return new Promise((resolve) => setTimeout(() => resolve({ data: {...} }), 300));

// After (real)
return axiosClient.get('/admin/stats');
```

## ✨ Features

- **Login/Register** with CSV-based demo auth
- **Admin Dashboard**: stats, sentiment pie chart, category bar chart, reviews table, product list
- **User Dashboard**: product catalog, category filter, sentiment overview, review details
- **Chatbot**: floating AI chat widget (admin + user modes)
- **Dark/Light theme** toggle with localStorage persistence
- **Protected routes** by role
